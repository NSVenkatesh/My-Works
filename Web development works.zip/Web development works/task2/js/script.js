$(document).ready(function(){
    var arr=[];
    var newarr=[];
    $("#btn").click(function(){
        $("ol").html("")
        var input=$("#input").val();
        $("#input").val("");
        list=input.split(";")
        arr.unshift(list)
        var x=arr.join(",")
        newarr=x.split(",");
        newarr = newarr.filter((item) => item !="");
        console.log(newarr)
        for(i in newarr){
            $("#list").append("<li>"+newarr[i]+"</li>");
        }
    })
})

// $(document).ready(function () {
//   var arr=[];
//   $("#btn").click(function () {
//     $("ol").html("");
//     var input = $("#input").val();
//     $("#input").val("");
//     list = input.split(";");
//     arr=list.concat(arr);
//     console.log(arr)
//     arr = arr.filter((item) => item !="");
//     for(i in arr){
//       $("#list").append("<li>"+arr[i]+"</li>");
//     }
//   });
// });

// for(i in newarr){
//   if(newarr[i]!=""){
//     arr1.push(newarr[i]);
//   }
// }