// $(document).ready(function () {
//     setTimeout(function () {
//         $(".images img").css({
//             "transform": "translateX(-100%)",
//             "transition": "5s all"
//         })
//     }, 3000)
//     setTimeout(function () {
//         $(".images img").css({
//             "transform": "translateX(-200%)",
//             "transition": "5s all"
//         })
//     }, 9000)
//     setTimeout(function () {
//         $(".images img").css({
//             "transform": "translateX(-300%)",
//             "transition": "5s all"
//         })
//     }, 15000)
//     setTimeout(function () {
//         $(".images img").css({
//             "transform": "translateX(0%)",
//             "transition": "5s all"
//         })
//     }, 22000)
// })

// $(document).ready(function () {
//   setTimeout(function () {
//     var img= $(".images img");
//     for (i = 0; i <= img.length; i++) {
//       $(img[i]).css({
//         "transform": "translateX(-100%)",
//         "transition": "5s all"
//       })
//     }
//   }, 3000)
// })

// $(document).ready(function(){
//     var img= $(".images img");
//     for(var i=0;i<img.length;i++){
        
//     }
// })

// $(document).ready(function () {
//   setTimeout(function () {
//     var img= $(".images img");
//     for (i = 0; i <= img.length; i++) {
//       $(".images").animate({
//         left:"-100%"
//       },5000)
//       $(".images").animate({
//         left:"-200%"
//       },5000)
//       $(".images").animate({
//         left:"-300%"
//       },5000)
//       $(".images").animate({
//         left:"0px"
//       },2000)
//     }
//   }, 3000)
// })