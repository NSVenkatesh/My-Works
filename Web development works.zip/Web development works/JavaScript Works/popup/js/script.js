$(document).ready(function(){
    $("#bt").click(function(){
        $("#p1").animate({opacity: '1',top:'15px'},500);
    });
    $("#bt1").click(function(){
        $("#p1").animate({opacity: '0'},1000);
        $("#p1").animate({top:'-215px'});
    });
    $("#bt2").click(function(){
        $("#p1").animate({opacity: '0'},1000);
        $("#p1").animate({top:'-215px'});
    });
});