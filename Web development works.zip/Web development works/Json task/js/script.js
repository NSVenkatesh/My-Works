var data1 = [];
$(document).ready(function () {
  $("#btn").click(function () {
    var num = $("#search").val();
    var data1 = JSON.parse(sessionStorage.getItem("data1"));
    if(data1==null){
      alert("Please Add 1 Student Mark details and then check results")
    }
    for (i in data1) {
      var r_num = data1[i].num;
      if (num == r_num) {
        $("#search").css("color", "black");
        $(".invalid").css("visibility", "hidden");
        $(".details").show();
        $(".details").find(".name span").html(data1[i].name);
        $(".details").find(".roll_no span").html(data1[i].num);
        $(".marks").find(".c_span").html(data1[i].c);
        $(".marks").find(".python_span").html(data1[i].python);
        $(".marks")
          .find(".web_development_span")
          .html(data1[i].web_development);
        $(".marks").find(".data_science_span").html(data1[i].data_science);
        var x =
          data1[i].c +
          data1[i].python +
          data1[i].web_development +
          data1[i].data_science;
        $("#total").html(x);
        return false;
      } else {
        $(".details").hide();
        $(".invalid").css("visibility", "visible");
        $("#search").css("color", "red");
      }
    }
  });
  $("#search").keyup(function () {
    $(".details").hide();
    $("#search").css("color", "black");
    $(".invalid").css("visibility", "hidden");
  });

  $("#result_page1").click(function () {
    $(".content").show();
    $(".main_page").hide();
  });
  $("#mark_entry_portal").click(function () {
    $(".entry_portal").show();
    $(".main_page").hide();
  });
  $("#result_page").click(function () {
    $(".content").show();
    $(".entry_portal").hide();
  });
  $("#home_page").click(function () {
    $(".content").hide();
    $(".main_page").show();
  });

  // Cancel button
  $("#cancel").click(function () {
    $(".mark_entry .marks input").val("");
  });
  
  // Submit Button...Mark entry
  var num = 100113;
  $("#submit").click(function () {
    var s_name = $("#name").val();
    var m_c = $("#c").val();
    var m_python = $("#python").val();
    var m_web_development = $("#web_development").val();
    var m_data_science = $("#data_science").val();
    if (
      s_name != "" &&
      m_c != "" &&
      m_python != "" &&
      m_web_development != "" &&
      m_data_science != ""
    ) {
      var x = {
        num: num,
        name: s_name,
        c: parseInt(m_c),
        python: parseInt(m_python),
        web_development: parseInt(m_web_development),
        data_science: parseInt(m_data_science),
      };
      data1.push(x);
      $("#name").val("");
      $("#c").val("");
      $("#python").val("");
      $("#web_development").val("");
      $("#data_science").val("");
      sessionStorage.setItem("data1", JSON.stringify(data1));
      alert(num + "   Submitted Successfully");
      num = num + 1;
    } else {
      alert("Invalid Entry");
    }
  });
});
