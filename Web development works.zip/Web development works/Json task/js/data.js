data1=[
    {
        num: 100101,
        name: "Aneesh",
        c: 87,
        python: 77,
        web_development: 92,
        data_science: 94
    },
    {
        num: 100102,
        name: "Balaji",
        c: 62,
        python: 71,
        web_development: 52,
        data_science: 44
    },
    {
        num: 100103,
        name: "Daniel",
        c: 84,
        python: 71,
        web_development: 69,
        data_science: 54
    },
    {
        num: 100104,
        name: "Edwin",
        c: 57,
        python: 82,
        web_development: 64,
        data_science: 74
    },
    {
        num: 100105,
        name: "Fernadus",
        c: 62,
        python: 71,
        web_development: 98,
        data_science: 54
    },
    {
        num: 100106,
        name: "Ganesh",
        c: 87,
        python: 90,
        web_development: 98,
        data_science: 69
    },
    {
        num: 100107,
        name: "Hari",
        c: 73,
        python: 64,
        web_development: 82,
        data_science: 64
    },
    {
        num: 100108,
        name: "Venkatesh",
        c: 69,
        python: 73,
        web_development: 94,
        data_science: 76
    },
    {
        num: 100109,
        name: "Kanagaraj",
        c: 74,
        python: 84,
        web_development: 97,
        data_science: 89
    },
    {
        num: 100110,
        name: "Logesh",
        c: 56,
        python: 71,
        web_development: 90,
        data_science: 82
    },
    {
        num: 100111,
        name: "Siva",
        c: 77,
        python: 85,
        web_development: 94,
        data_science: 81
    },
    {
        num: 100112,
        name: "Vignesh",
        c: 71,
        python: 66,
        web_development: 89,
        data_science: 77
    }
]