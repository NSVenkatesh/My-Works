$(function(){
    $('#box').hide();

    $(document).bind("contextmenu", function() {
        $('#box').show();
        $("#box").offset({left:event.pageX+15, top:event.pageY-25});
        event.preventDefault();
    });

    $(document).click(function(e) {
        $('#box').hide();
    });
    $('#box').click(function(e) {
        $('#box').hide();
    });
});