var u,x,y,op;
var a,b;
var firstnum,secondnum;
$(document).ready(function(){
    $("#f").click(function(){
        $(".hide").toggle();
    });
});
function clr(){
    $('#res').val("");
    $('.hist').val("");
    $('.hist1').val("");
}
function del(){
    a=$('#res').val();
    b=a.slice(0,length-1);
    $("#res").val(b);
}
function input(a){
    var y=$("#res").val();
    var x=$(a).val();
    $("#res").val(y+x);
}
function operator(y){
    firstnum=$("#res").val();
    op=y;
    $('#res').val(firstnum+op);
}
function solve(){
    var z=$('#res').val();
    secondnum=z.slice(firstnum.length+op.length);
    $('.hist').val(z);
    if(op=="+"){
        $('#res').val(parseFloat(firstnum)+parseFloat(secondnum));
    }
    else if(op=="-"){
        $('#res').val(parseFloat(firstnum)-parseFloat(secondnum));
    }
    else if(op=="*"){
        $('#res').val(parseFloat(firstnum)*parseFloat(secondnum));
    }
    else if(op=="/"){
        $('#res').val(parseFloat(firstnum)/parseFloat(secondnum));
    }
    else if(op=="%"){
        $('#res').val(parseFloat(firstnum)%parseFloat(secondnum));
    }
    else if(op=="**"){
        $('#res').val(parseFloat(firstnum)**parseFloat(secondnum));
    }
    u=$('#res').val();
    $('.hist1').val("= "+u);
}